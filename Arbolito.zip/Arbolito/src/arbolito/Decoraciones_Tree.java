package arbolito;

public class Decoraciones_Tree {
    private int Can_Sphere;
    private int Can_stars;
    private double Size_tie;

    public int getCan_Sphere() {
        return Can_Sphere;
    }

    public void setCan_Sphere(int Can_Sphere) {
        this.Can_Sphere = Can_Sphere;
    }

    public int getCan_stars() {
        return Can_stars;
    }

    public void setCan_stars(int Can_stars) {
        this.Can_stars = Can_stars;
    }

    public float getSize_tie() {
        return (float) Size_tie;
    }
   
    public void setSize_tie(float Size_tie) {
        this.Size_tie = Size_tie;
    }
    
       public Decoraciones_Tree(int Can_Sphere, int Can_stars, double Size_tie){
        this.Can_Sphere = Can_Sphere;
        this.Can_stars = Can_stars;
        this.Size_tie = Size_tie;
        
       }
    
     public void spcsD(){
         System.out.println("el cula posee "+Can_Sphere+" esferas, "+Can_stars+" estrellas y tiene un lazo decorativo de "+Size_tie+"cm");
     
     }
}
