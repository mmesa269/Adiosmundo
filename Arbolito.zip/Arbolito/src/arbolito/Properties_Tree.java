package arbolito;

public class Properties_Tree {
    
    private String tipo_arbol;
    private int edad_de_arbol;
    private double Tamaño;
 
    public String gettipo_arbol() {
        return tipo_arbol;
    }

    public void settipo_arbol(String tipo_arbol) {
        this.tipo_arbol = tipo_arbol;
    }
  
    public int getedad_de_arbol() {
        return edad_de_arbol;
    }

    public void setedad_de_arbol(int edad_de_arbol) {
        this.edad_de_arbol = edad_de_arbol;
    }
   
    public float getTamaño() {
        return (float) Tamaño;
    }

    public void setTamaño(float Tamaño) {
        this.Tamaño = Tamaño;
    }
    
        public Properties_Tree(int edad_de_arbol, String tipo_arbol, double Tamaño){
        this.edad_de_arbol = edad_de_arbol;
        this.tipo_arbol = tipo_arbol;
        this.Tamaño = Tamaño;
           }
    
     public void spcs(){
         System.out.println("el arbol "+tipo_arbol+" de  "+edad_de_arbol+" años mide: "+Tamaño+"mts");
     
     }
}
