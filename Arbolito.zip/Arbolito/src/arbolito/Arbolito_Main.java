package arbolito;

import java.util.Scanner;

public class Arbolito_Main {

    public static void main(String[] args) {
        
        
        Scanner in = new Scanner(System.in);
        int canSphere, canStars, ageTree;
        double Size, sizeTie;
        String typeTree;
        ageTree = 0;
        Size = 0;
        
        //tipo de arbol con caracteristicas
        System.out.println("Porfavor seleccione el tipo de arbol que desea:"
                + "\n 1). Pino."
                + "\n 2). Abedul."
                + "\n 3). Roble.");
        typeTree = in.next();
                
        switch (typeTree){
            case "1":
               System.out.println("Se ah seleccionado como tipo de arbol pino"
                       + "\n porfavor seleccione entre los siguientes arboles segun la edad"
                       + "\n 1). pino_1: 19años"
                       + "\n 2). pino_2: 9años"
                       + "\n 3). pino_3: 6años"
                       + "\n tenga encuenta que entre menor edad mas pequeño el arbol.");
               ageTree =in.nextInt();
               typeTree = "pino";
                switch (ageTree){
                    case 1:
                        System.out.println("ah seleccionado el Pino_1 de 19años de edad el cual tiene un tamaño de 16mts");
                        Size= 16.0;
                        break;
                    case 2:
                        System.out.println("ah seleccionado el Pino_2 de 9años de edad el cual tiene un tamaño de 10mts");
                        Size= 10.0;
                        break;
                    case 3:
                        System.out.println("ah seleccionado el Pino_3 de 6años de edad el cual tiene un tamaño de 3mts");
                        Size= 3.0;
                        break;
                }
               break;
            case "2":
                System.out.println("Se ah seleccionado como tipo de arbol Abedul"
                       + "\n porfavor seleccione entre los siguientes arboles segun la edad"
                       + "\n 1). Abedul_1: 10años"
                       + "\n 2). Abedul_2: 4años"
                       + "\n 3). Abedul_3: 15años"
                       + "\n tenga encuenta que entre menor edad mas pequeño el arbol.");
                ageTree =in.nextInt();
                typeTree = "Abedul";
                switch (ageTree){
                    case 1:
                        System.out.println("ah seleccionado el Abedul_1 de 10años de edad el cual tiene un tamaño de 8mts");
                        Size= 8.0;
                        break;
                    case 2:
                        System.out.println("ah seleccionado el Abedul_2 de 4años de edad el cual tiene un tamaño de 3mts");
                        Size= 3.0;
                        break;
                    case 3:
                        System.out.println("ah seleccionado el Abedul_3 de 15años de edad el cual tiene un tamaño de 15mts");
                        Size= 15.0;
                        break;
                }
                break;
            case "3":
                System.out.println("Se ah seleccionado como tipo de arbol Roble"
                       + "\n porfavor seleccione entre los siguientes arboles segun la edad"
                       + "\n 1). Roble_1: 5años"
                       + "\n 2). Roble_2: 11años"
                       + "\n 3). Roble_3: 3años"
                       + "\n tenga encuenta que entre menor edad mas pequeño el arbol.");
                ageTree =in.nextInt();
                typeTree = "Roble";
                switch (ageTree){
                     case 1:
                        System.out.println("ah seleccionado el Roble_1 de 5años de edad el cual tiene un tamaño de 6mts");
                        Size= 6.0;
                        break;

                    case 2:
                        System.out.println("ah seleccionado el Roble_2 de 11años de edad el cual tiene un tamaño de 13mts");
                        Size= 13.0;
                        break;
                    case 3:
                        System.out.println("ah seleccionado el Roble_3 de 3años de edad el cual tiene un tamaño de 3mts");
                        Size= 3.0;
                        break;
                }
                break;

        }
        
             
        //Decoracion del arbol
        System.out.println("/////////////////////////////////////////////////////////////////////////");
        System.out.println("Ingrese la cantidad de esferas que desea en su arbol navideño");
        canSphere =in.nextInt();
        System.out.println("/////////////////////////////////////////////////////////////////////////");
        System.out.println("Ingrese la cantidad de estrellas que desea en el arbol navideño");
        canStars=in.nextInt();
        System.out.println("/////////////////////////////////////////////////////////////////////////");
        System.out.println("Ingrese el largo del lazo decorativo del arbol en cm");
        sizeTie=in.nextFloat();
        System.out.println("/////////////////////////////////////////////////////////////////////////");
        
        
       //gets
       System.out.println("/////////////////////////////////////////////////////////////////////////");
        Properties_Tree c1 = new Properties_Tree(ageTree, typeTree, Size);
         c1.spcs();
         Decoraciones_Tree c2 = new Decoraciones_Tree(canSphere, canStars, sizeTie);
         c2.spcsD();
       System.out.println("/////////////////////////////////////////////////////////////////////////");
        
        
        
    }
    
    
}
